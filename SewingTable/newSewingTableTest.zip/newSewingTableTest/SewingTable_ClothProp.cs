﻿using System;
using Sims3.Gameplay.Abstracts;
using Sims3.Gameplay.Interfaces;
using Sims3.Gameplay.Objects.Decorations.Mimics;
using Sims3.SimIFace;

namespace Sims3.Gameplay.Objects.Lyralei
{
	/// <summary>
	/// Description of SewingTable_ClothProp.
	/// </summary>
	public class SewingTable_ClothProp : GameObject
	{
		public override void OnCreation()
		{
			base.SetHiddenFlags(HiddenFlags.Everything);
			base.OnCreation();
		}
	}
}
