﻿using System;
using Sims3.Gameplay.Abstracts;
using Sims3.Gameplay.Actors;
using Sims3.Gameplay.ActorSystems;
using Sims3.Gameplay.Autonomy;
using Sims3.Gameplay.Interactions;
using Sims3.Gameplay.Interfaces;
using Sims3.Gameplay.Objects.Seating;
using Sims3.Gameplay.Skills;
using Sims3.SimIFace;
using Sims3.UI;
using Sims3.Gameplay.Objects.HobbiesSkills;

namespace Sims3.Gameplay.Objects.Lyralei
{
	public class SewingTable : GameObject, IChairOwningSurface
	{
		/* Pre-startup
		*  - Get Fabric/cloth
		*  - Find the chair
		*  - Skill level (Do later)
		*  - Progress (Do later)
		*  - Get all sewing thingies you can make!
		*/
		
		/* Startup
		*  - Make sure that the sim is sitting on the chair
		*  - That the table is not in use. 
		*/
		
	   /* Progress
		*  - Initiate the Fabric/Cloth prop. 
		*  - Grab the Jazz script.
		*  - Skillset activated (Do later)
		*  - base.BeginCommodityUpdates();
		*  - Aquire the animation name. 
		*  - Call the sims, but also the objects (cloth included).
		*  - Animate the sim or object
		*  - After finished/canceled, play exit animation
		*  - base.EndCommodityUpdates();
		*  - base.StandardExit();
		*/
		
		/* EXIT
		 *  - After done, put crafty thing in Inventory. 
		 */

		public class Sewing : Interaction<Sim, SewingTable>
        {
            public class Definition :  InteractionDefinition<Sim, SewingTable, Sewing>
            {
                public override string GetInteractionName(Sim actor, SewingTable target, InteractionObjectPair interaction)
                {
                    return "Talk To Me";
                }
                
                public override bool Test(Sim actor, SewingTable target, bool isAutonomous, ref GreyedOutTooltipCallback greyedOutTooltipCallback)
                {
                	// The code below will check if there's a chair attached to any containment slot. 
                	if (target.GetTotalNumChairsAtTable() < 1)
					{
						actor.ShowTNSIfSelectable("Has no chair attached", StyledNotification.NotificationStyle.kSimTalking);
						return false;
					}
                	
                	if (target.GetNumAvailableChairSlots(actor) == 0 && !target.IsActorSittingAtTable(actor))
					{
						actor.ShowTNSIfSelectable("In use!", StyledNotification.NotificationStyle.kSimTalking);
						return false;
					}

	            	return true;
                }
            }
            
            public static InteractionDefinition Singleton = new Definition();
            
            public SewingTable_ClothProp mFabric = null;
            
            public SkillNames mSkillName;
            
            public override bool Run()
            {
            	if (!base.Target.ScootInActor(base.Actor))
				{
					base.Actor.PlayRouteFailThoughtBalloon(base.Target.GetThumbnailKey());
					return false;
				}
            	
            	base.StandardEntry();
//				Skill skill = base.Actor.SkillManager.AddElement(SkillNames.Painting);
//				
//				if (base.Actor.TraitManager.HasElement(TraitNames.Artistic))
//				{
//					base.Actor.SkillManager.ChangeSkillGainModifier(skill.Guid, 0.5f);
//				}
//				
				//base.BeginCommodityUpdates();
            	
				//Add in object GUID/ Prop whenever done
				
				/* Needs to line up with Jazz script:
 				* "SewingTable" = MachineName,
				* "Enter" = Entry state 
				* "X" = Actor
				* "sewingtable_table" = Actor (table)
				*/
				
				Vector3 slotPosition = base.Target.GetSlotPosition(Slot.ContainmentSlot_1);
				Vector3 forwardSlot = base.Target.GetForwardOfSlot(Slot.ContainmentSlot_1);
				
				Actor.ShowTNSIfSelectable("passed Slot Position", StyledNotification.NotificationStyle.kSimTalking);

				base.EnterStateMachine("SewingTable", "Enter", "x");
				
				SewingTable_ClothProp mFabric = new SewingTable_ClothProp();
				string fabricRK = "0x319E4F1D:0x00000000:0x00000000C3BEFD4A";
				//mFabric = GlobalFunctions.CreateObject(ResourceKey.FromString(fabricRK), ProductVersion.BaseGame, slotPosition, 0, forwardSlot, null, null) as SewingTable_ClothProp;
				mFabric = (SewingTable_ClothProp)GlobalFunctions.CreateObject(ResourceKey.FromString(fabricRK), Target.Position, Target.Level, Target.Position);
				
				if(mFabric != null)
				{
					mFabric.ParentToSlot(base.Target, Slot.ContainmentSlot_1);
					base.SetActor("fabric", mFabric);
					Actor.ShowTNSIfSelectable("Object found", StyledNotification.NotificationStyle.kSimTalking);
				}
				
				Actor.ShowTNSIfSelectable("Created the object", StyledNotification.NotificationStyle.kSimTalking);
				
				base.SetActor("sewingtable_table", base.Target);
				base.SetActor("sewingtable_fabric", base.Target);
				base.SetActor("chairDining", base.Actor.Posture.Container);           	
				// Defines Actor and State name
            	base.EnterState("x", "Enter");	
            	
            	//bool flag = DoLoop(ExitReason.Default, SewingLoop, base.mCurrentStateMachine);
            	
            	base.AnimateSim("Exit");

            	//base.EndCommodityUpdates(flag);
            	base.StandardExit();
                return true;
            }
            
            
           
           public override void Cleanup()
           {
           	base.Cleanup();
           }
            
        }
		
		public static Slot[] sContainmentSlotChair = new Slot[4]
		{
			Slot.ContainmentSlot_0,
			Slot.ContainmentSlot_1,
			Slot.ContainmentSlot_2,
			Slot.ContainmentSlot_3
		};
		
		public override bool IsObjectInFrontOfMe(IGameObject gameObject)
		{
			ChairDining chairDining = gameObject as ChairDining;
			if (chairDining == null)
			{
				return false;
			}
			SewingTable sewingTable = chairDining.Parent as SewingTable;
			return sewingTable == this;
		}
		
		public int GetTotalNumChairsAtTable()
		{
			int num = 0;
			Slot[] containmentSlots = base.GetContainmentSlots();
			Slot[] array = containmentSlots;
			foreach (Slot slotName in array)
			{
				IGameObject containedObject = base.GetContainedObject(slotName);
				if (containedObject != null)
				{
					num++;
				}
			}
			return num;
		}
			
		public bool IsActorSittingAtTable(Sim a)
		{
			Slot[] containmentSlots = base.GetContainmentSlots();
			Slot[] array = containmentSlots;
			foreach (Slot slotName in array)
			{
				IGameObject containedObject = base.GetContainedObject(slotName);
				if (containedObject != null && containedObject.IsActorUsingMe(a))
				{
					return true;
				}
			}
			return false;
		}		
		
		public int GetNumAvailableChairSlots(Sim a)
		{
			int num = 0;
			Slot[] containmentSlots = base.GetContainmentSlots();
			Slot[] array = containmentSlots;
			foreach (Slot slotName in array)
			{
				IGameObject containedObject = base.GetContainedObject(slotName);
				if (containedObject != null && (!containedObject.InUse || containedObject.IsActorUsingMe(a)))
				{
					num++;
				}
			}
			return num;
		}
		
		// Kindly stolen from Domino chair
		public bool ScootInActor(Sim actor)
		{
			if (actor != null && actor.Posture != null)
			{
				ChairDining chairDining = actor.Posture.Container as ChairDining;
				if (chairDining != null && chairDining.Parent != null && actor.CurrentInteraction != null)
				{
					if (chairDining.ChairState == ChairDining.State.Angled && base.Parent != actor)
					{
						InteractionInstance interactionInstance = SitTransitionAngledToStraight.Singleton.CreateInstance(actor.Posture.Container, actor, actor.CurrentInteraction.GetPriority(), false, false);
						return interactionInstance.RunInteraction();
					}
					if (chairDining.ChairState == ChairDining.State.Straight)
					{
						return true;
					}
				}
			}
			return false;
		}
		
		public override void OnCreation()
		{
			base.OnCreation();
		}
		
		public override void OnStartup()
		{
			base.AddInteraction(Sewing.Singleton);
		}
	}
}